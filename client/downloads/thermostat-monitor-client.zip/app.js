require('coffee-script')
require('./app.coffee')